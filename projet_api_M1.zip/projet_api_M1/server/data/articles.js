const films = [
    {
      id: 1,
      title: "Spider-Man: No Way Home",
      film_type: 'Action',
      image1: "https://image.over-blog.com/CTzM3GtwJopHQX6FoZU5lI7Gsoo=/filters:no_upscale()/image%2F0995735%2F20211203%2Fob_afa363_untitled-1-41.jpg",
      image2: "https://media-assets.vanityfair.it/photos/61a0c30a71c4862227952457/16:9/w_2560%2Cc_limit/reo.jpeg",
      release_date: '2021-12-15',
      producer: "Emily Fong",
      sessions: [
        { place: '75001', date: '18 Dec 2023', hour: '12h30', city: [{ 'postal_code': '75001', 'city_name': 'Paris', 'city_id': 1 }] },
        { place: '33000', date: '20 Dec 2023', hour: '14h30', city: [{ 'postal_code': '33000', 'city_name': 'Bordeaux', 'city_id': 10 }] },
        { place: '69002', date: '24 Dec 2023', hour: '16h00', city: [{ 'postal_code': '69002', 'city_name': 'Lyon', 'city_id': 7 }] }
      ],
      actors: ['Tom Holland', 'Zendaya'],
      duration: '02:28:00'
    },
    {
      id: 2,
      title: "Dune",
      film_type: 'Science-Fiction',
      image1: "https://mr.comingsoon.it/imgdb/locandine/big/55957.jpg",
      image2: "https://phototrend.fr/wp-content/uploads/2022/03/dune-affiche.jpg",
      release_date: '2021-09-15',
      producer: "Jon Spaihts",
      sessions: [
        { place: '13001', date: '22 Dec 2023', hour: '11h00', city: [{ 'postal_code': '13001', 'city_name': 'Marseille', 'city_id': 8 }] },
        { place: '75008', date: '23 Dec 2023', hour: '18h45', city: [{ 'postal_code': '75008', 'city_name': 'Paris', 'city_id': 2 }] },
        { place: '69001', date: '24 Dec 2023', hour: '13h15', city: [{ 'postal_code': '69001', 'city_name': 'Lyon', 'city_id': 6 }] }
      ],
      actors: ['Timothée Chalamet', 'Zendaya'],
      duration: '02:35:00'
    },
    {
      id: 3,
      title: "Eternals",
      film_type: 'Action',
      image1: "https://images.moviesanywhere.com/acdd3c73c67d756fb920845ad7c88c8f/eb62e721-3ce3-4ec0-b44c-1bd8bc073d87.jpg",
      image2: "https://m.media-amazon.com/images/M/MV5BYzFmZDQ3ZjAtYTQ2Ni00ZWY5LWI0OGQtNjlmZDhiNjRmYmFlXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_.jpg",
      release_date: '2021-10-18',
      producer: "Chloé Zhao",
      sessions: [
        { place: '13002', date: '26 Dec 2023', hour: '10h30', city: [{ 'postal_code': '13002', 'city_name': 'Marseille', 'city_id': 9 }] },
        { place: '75010', date: '27 Dec 2023', hour: '17h00', city: [{ 'postal_code': '75010', 'city_name': 'Paris', 'city_id': 5 }] },
        { place: '75011', date: '28 Dec 2023', hour: '14h00', city: [{ 'postal_code': '75011', 'city_name': 'Paris', 'city_id': 3 }] }
      ],
      actors: ['Angelina Jolie', 'Richard Madden'],
      duration: '02:37:00'
    },
    {
      id: 4,
      title: "No Time to Die",
      film_type: 'Action',
      image1: "https://m.media-amazon.com/images/M/MV5BYWQ2NzQ1NjktMzNkNS00MGY1LTgwMmMtYTllYTI5YzNmMmE0XkEyXkFqcGdeQXVyMjM4NTM5NDY@._V1_.jpg",
      image2: "https://static1.colliderimages.com/wordpress/wp-content/uploads/2021/09/007-no-time-to-die.jpg",
      release_date: '2021-09-28',
      producer: "Cary Joji Fukunaga",
      sessions: [
        { place: '75011', date: '26 Dec 2023', hour: '16h15', city: [{ 'postal_code': '75011', 'city_name': 'Paris', 'city_id': 3 }] },
        { place: '75001', date: '28 Dec 2023', hour: '18h30', city: [{ 'postal_code': '75001', 'city_name': 'Paris', 'city_id': 1 }] },
        { place: '69002', date: '4 Jan 2024', hour: '12h45', city: [{ 'postal_code': '69002', 'city_name': 'Lyon', 'city_id': 7 }] }
      ],
      actors: ['Daniel Craig', 'Léa Seydoux'],
      duration: '02:43:00'
    },
    {
      id: 5,
      title: "Black Widow",
      film_type: 'Action',
      image1: "https://fr.web.img2.acsta.net/pictures/21/06/30/13/37/5245550.jpg",
      image2: "https://images.thedirect.com/media/article_full/black-widow-characters.jpg",
      release_date: '2021-07-07',
      producer: "David Hayter",
      sessions: [
        { place: '69002', date: '30 Dec 2023', hour: '19h20', city: [{ 'postal_code': '69002', 'city_name': 'Lyon', 'city_id': 7 }] },
        { place: '75001', date: '6 Jan 2024', hour: '13h45', city: [{ 'postal_code': '75001', 'city_name': 'Paris', 'city_id': 1 }] },
        { place: '33000', date: '4 Jan 2024', hour: '15h30', city: [{ 'postal_code': '33000', 'city_name': 'Bordeaux', 'city_id': 10 }] }
      ],
      actors: ['Scarlett Johansson', 'Florence Pugh'],
      duration: '02:14:00'
    },
    {
      id: 6,
      title: 'Shang-Chi and the Legend of the Ten Rings',
      image1: "https://cdn0-production-images-kly.akamaized.net/UMgBFvYF92XfTQ6WUoyFF72s6qY=/800x1066/smart/filters:quality(75):strip_icc():format(webp)/kly-media-production/medias/3583521/original/059777100_1632628838-Shang-Chi_and_the_Legend_of_the_Ten_Rings_0.jpg",
      image2: "https://datg-cms-source-repo.s3.amazonaws.com/ABC/DisneyPlusMisc/H_DisneyDay_16x9_ShangChi/e72f340c-73f9-47e7-8d34-dba9111332bf.jpg",
      film_type: 'Action',
      release_date: '2021-09-01',
      producer: "Sean Miyashiro",
      sessions: [
        { place: '69002', date: '6 Jan 2024', hour: '11h15', city: [{ 'postal_code': '69002', 'city_name': 'Lyon', 'city_id': 7 }] },
        { place: '13001', date: '8 Jan 2024', hour: '16h00', city: [{ 'postal_code': '13001', 'city_name': 'Marseille', 'city_id': 8 }] },
        { place: '75008', date: '10 Jan 2024', hour: '12h00', city: [{ 'postal_code': '75008', 'city_name': 'Paris', 'city_id': 2 }] }
      ],
      actors: ['Simu Liu', 'Awkwafina'],
      duration: '02:12:00'
    },
    {
      id : 7,
      title: 'The Matrix Resurrections',
      image1: "https://media.senscritique.com/media/000020350782/300/matrix_resurrections.png",
      image2: "https://imgsrc.cineserie.com/2022/09/the-matrix-resurrections-h2.jpeg?ver=1",
      film_type: 'Science-Fiction',
      release_date: '2021-12-22',
      actors: ('Keanu Reeves', 'Carrie-Anne Moss'),
      producer: "Lana Wachowski",
      sessions:
      [
        { place: 'Lyon 69001', date: '30 Jan 2024', hour: '12h15', city: [{ 'postal_code': '69001', 'city_name': 'Lyon', 'city_id': 6 }]  },
        { place: 'Marseilles 13002', date: '1 Feb 2024', hour: '15h45', city:[{'postal_code': '13002', 'city_name': 'Marseille', 'city_id': 9}]},
        { place: 'Paris 75010', date: '3 Feb 2024', hour: '10h30', city:[{'postal_code': '75010', 'city_name': 'Paris', 'city_id': 5}] }
      ],
      duration: '02:28:00'
    },
    {
      id : 8,
      title: 'Venom: Let There Be Carnage',
      image1: "https://fr.web.img2.acsta.net/pictures/21/09/01/11/19/0900123.jpg",
      image2: "https://chocobonplan.com/wp-content/uploads/2021/05/venom-2-1.jpg",
      film_type: 'Action',
      release_date: '2021-09-30',
      actors: ('Tom Hardy', 'Woody Harrelson'),
      producer: "Matt Tolmach",
      sessions:
      [
        { place: 'Lyon 69001', date: '12 Jan 2024', hour: '19h45', city: [{ 'postal_code': '69002', 'city_name': 'Lyon', 'city_id': 6 }]},
        { place: 'Marseilles 13002', date: '14 Jan 2024', hour: '10h00', city:[{'postal_code': '13002', 'city_name': 'Marseille', 'city_id': 9}] },
        { place: 'Paris 75010', date: '16 Jan 2024', hour: '15h15', city:[{'postal_code': '75010', 'city_name': 'Paris', 'city_id': 5}] }
      ],
      duration: '01:37:00'
    },
    {
      id : 9,
      title: 'Ghostbusters: Afterlife',
      image1: "https://images.fandango.com/ImageRenderer/0/0/redesign/static/img/default_poster.png/0/images/masterrepository/Fandango/219412/GBAL_OnLine_667x1000.jpg",
      image2: "https://thestylus.org/wp-content/uploads/2021/11/ghostbusters_afterlife.jpg",
      film_type: 'Action', 
      release_date: '02:04:00',
      actors: ('Finn Wolfhard, Mckenna Grace'),
      producer: "Jason Reitman",
      sessions:
      [
        { place: 'Paris 75011', date: '18 Jan 2024', hour: '14h30', city:[{'postal_code': '75011', 'city_name': 'Paris', 'city_id': 3}] },
        { place: 'Lyon 69002', date: '20 Jan 2024', hour: '16h45', city: [{ 'postal_code': '69002', 'city_name': 'Lyon', 'city_id': 6 }] },
        { place: 'Paris 75001', date: '22 Jan 2024', hour: '11h30', city:[{'postal_code': '75001', 'city_name': 'Paris', 'city_id': 1}] }
      ],
      city:[{'postal_code': 'Lyon 69001', 'city_name': 'Lyon', 'city_id': 6}],
      duration: '2021-11-19'
    },
    {
      id : 10,
      title: 'Downton Abbey: A New Era',
      image1: "https://fr.web.img4.acsta.net/pictures/22/02/15/09/10/5252741.jpg",
      image2: "https://i0.wp.com/www.haworthcinema.org.uk/wp-content/uploads/2022/08/downton-web.jpg?fit=900%2C467&ssl=1",
      film_type: 'Drama',
      release_date: '2022-03-17',
      actors: ('Hugh Bonneville, Michelle Dockery'),
      producer: "Julian Fellowes",
      sessions:
      [
        { place: 'Bordeaux 33000', date: '24 Jan 2024', hour: '18h00', city:[{'postal_code': '33000', 'city_name': 'Bordeaux', 'city_id': 10}]},
        { place: 'Lyon 69002', date: '26 Jan 2024', hour: '13h00', city: [{ 'postal_code': '69002', 'city_name': 'Lyon', 'city_id': 6 }] },
        { place: 'Paris 75008', date: '28 Jan 2024', hour: '17h30', city: [{'postal_code': '75008', 'city_name': 'Paris', 'city_id': 2}] }
      ],
      duration: '02:23:00'
}
  ]
  
module.exports = films

  