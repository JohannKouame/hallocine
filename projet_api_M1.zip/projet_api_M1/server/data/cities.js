const cities = [
    // {'postal_code': 'Paris 75001', 'city_name': 'Paris', 'city_id': 1},
    {'postal_code': '75001', 'city_name': 'Paris', 'city_id': 1},
    {'postal_code': '75008', 'city_name': 'Paris', 'city_id': 2},
    {'postal_code': '75011', 'city_name': 'Paris', 'city_id': 3},
    {'postal_code': '75012', 'city_name': 'Paris', 'city_id': 4},
    {'postal_code': '75010', 'city_name': 'Paris', 'city_id': 5},
    {'postal_code': '69001', 'city_name': 'Lyon', 'city_id': 6},
    {'postal_code': '69002', 'city_name': 'Lyon', 'city_id': 7},
    {'postal_code': '13001', 'city_name': 'Marseille', 'city_id': 8},
    {'postal_code': '13002', 'city_name': 'Marseille', 'city_id': 9},
    {'postal_code': '33000', 'city_name': 'Bordeaux', 'city_id': 10}
  ]
  
  module.exports = cities