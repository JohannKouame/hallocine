// const mysql = require('mysql')
const express = require('express')
var userIn = 0
var articleIn = 0

//****SQL */
// const connection = mysql.createConnection({
//   host: "localhost",
//   user: "root",
//   password: "PasswordMySQL1!",
//   database: "db_allocine",
// })
// const app = require("../../client/vue-application.js")
//TEST DE CONNEXION  A LA BASE DE DONNEES
// connection.connect((err, result)=>{
//   if(err) throw err;
//   console.log("Bien connecté: " + typeof(articles))
// })

//TEST REQUETE <<SELECT>> A LA BASE DE DONNEES
// connection.query("SELECT * FROM users", function (err, result, fields){
//   if (err) throw err;
//   console.log(result);
// })
let users = require("../data/users.js")
let films = require("../data/articles.js")


 const router = express.Router()
 //require : importer les fichiers (ici les articles)
//  const articles = require('../data/articles.js')
 
//  class Panier {
//    constructor () {
//     this.createdAt = new Date()
//     this.updatedAt = new Date()
//     //un article sera représenter par son id dans le tableau de panier
//     this.articles = []
//    }
//  }
 
 /*
  * Dans ce fichier, vous trouverez des exemples de requêtes GET, POST, PUT et DELETE
  * Ces requêtes concernent l'ajout ou la suppression d'articles sur le site
  * Votre objectif est, en apprenant des exemples de ce fichier, de créer 
  * l'API pour le panier de l'utilisateur
  *
  * Notre site ne contient pas d'authentification, ce qui n'est pas DU TOUT recommandé.
  * De même, les informations sont réinitialisées à chaque redémarrage du serveur, 
  * car nous n'avons pas de système de base de données pour faire persister les données
  */
 
 
 /*
  * Cette route doit retourner le panier de l'utilisateur, grâce à req.session
  */
 
 /*
  * Cette route doit permettre de changer la quantité d'un article dans le panier
  * Le body doit contenir la quantité voulue
  */
//
 router.post('/user/login', (req, res) => {
    // console.log("zfzefz " + users)
    console.log("request started")
    let username = req.body.username
    let password = req.body.password
    console.log(username)
    console.log(password)
    let isIn = -1
    users.forEach(user => {
      if (user.username === username && user.password === password){
        isIn = 1
      }
    });
    res.json(isIn)
  })
 
 /**
  * Cette route envoie l'intégralité des articles du site
  */

 router.get('/users', (req, res) => {
      connection.query("SELECT * FROM Users", function (err, result, fields) {
        if (err) throw err;
        console.log(result)
        res.json(result)
      })
 })

 router.get('/films', (req, res) => {
  console.log("connexion" ,connection)
      connection.query("SELECT * FROM Film", function (err, result, fields) {
        if (err) throw err;
        console.log(result)
        res.json(result)
      });
 })


 router.post('/films/adding', (req, res) =>{
  const image1 = req.body.image1
  const image2 = req.body.image2
  const title = req.body.title
  const name = req.body.name
  const film_type = req.body.film_type
  const release_date = req.body.release_date
  const producer = req.body.producer
  const actors = req.body.actors
  const sessions = req.body.sessions
  const duration = req.body.duration
  var film = {
    id : films.length+1,
    title : title,
    image1 : image1,
    image2 : image2,
    name : name,
    film_type : film_type,
    release_date : release_date,
    producer : producer,
    actors : actors,
    sessions : sessions,
    duration : duration,
}
  films.push(film)
  res.json(film)
 })
/*
* Cette fonction fait en sorte de valider que l'article demandé par l'utilisateur
* est valide. Elle est appliquée aux routes:
* - GET /article/:articleId
* - PUT /article/:articleId
* - DELETE /article/:articleId
* Comme ces trois routes ont un comportement similaire, on regroupe leurs
* fonctionnalités communes dans un middleware
*/
function isUserIn(user){
  connection.query("SELECT * FROM users", function (err, result, fields) {
    if (err) throw err;
    JSON.parse(JSON.stringify(result)).forEach(u => {
      if(u.tel == user.tel || u.mail == user.mail){
        userIn = -1
      }
      else userIn = 1
    })
  })
}
function isArticleIn(article){
  connection.query("SELECT * FROM articles", function (err, result, fields) {
    if (err) throw err;
    JSON.parse(JSON.stringify(result)).forEach(a => {
      if(a.name == article.name && 
        a.serie == article.serie &&
        a.graphicCardName == article.graphicCardName &&
        a.graphicCardSerie == article.graphicCardSerie &&
        a.graphicCardCapacity == article.graphicCardCapacity){
          articleIn = -1
          console.log("fsffdfsdfdsf :" + a.name)
      }
      else {articleIn = 1
      console.log("user not in: "+articleIn)}
    })
  })
}

 function parseArticle (req, res, next) {
   const articleId = parseInt(req.params.articleId)
   // si articleId n'est pas un nombre (NaN = Not A Number), alors on s'arrête
   if (isNaN(articleId)) {
     res.status(400).json({ message: 'articleId should be a number' })
     return
    }
   // on affecte req.articleId pour l'exploiter dans toutes les routes qui en ont besoin
   req.articleId = articleId
   
   const article = articles.find(a => a.id === req.articleId)
   if (!article) {
     res.status(404).json({ message: 'article ' + articleId + ' does not exist' })
     return
    }
    // on affecte req.article pour l'exploiter dans toutes les routes qui en ont besoin
    req.article = article
    next()
  }
  
  //En fonction d'une entrée d'articleId
  router.route('/article/:articleId')
  /**
  * Cette route envoie un article particulier
   */
  .get(parseArticle, (req, res) => {
    // req.article existe grâce au middleware parseArticle
    res.json(req.article)
  })


  
  router.delete('/article/:articleId', (req, res) => {
    var parametre = parseInt(req.params.articleId)
    connection.query('DELETE FROM articles WHERE id_article = ?', [[parametre]], 
    function (err, response) {
      if (err) throw err
      else{
        if(response.affectedRows) res.json(1)
        else res.json(-1)
      }
    })
  })
  
  module.exports = router
