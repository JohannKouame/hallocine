/*INSERT INTO Film (name, type, release_date, actors, duration)
VALUES
('Spider-Man: No Way Home', 'Action', '2021-12-15', 'Tom Holland, Zendaya', '02:28:00'),
('Dune', 'Science-Fiction', '2021-09-15', 'Timothée Chalamet, Zendaya', '02:35:00'),
('Eternals', 'Action', '2021-10-18', 'Angelina Jolie, Richard Madden', '02:37:00'),
('No Time to Die', 'Action', '2021-09-28', 'Daniel Craig, Léa Seydoux', '02:43:00'),
('Black Widow', 'Action', '2021-07-07', 'Scarlett Johansson, Florence Pugh', '02:14:00'),
('Shang-Chi and the Legend of the Ten Rings', 'Action', '2021-09-01', 'Simu Liu, Awkwafina', '02:12:00'),
('The Matrix Resurrections', 'Science-Fiction', '2021-12-22', 'Keanu Reeves, Carrie-Anne Moss', '02:28:00'),
('Venom: Let There Be Carnage', 'Action', '2021-09-30', 'Tom Hardy, Woody Harrelson', '01:37:00'),
('Ghostbusters: Afterlife', 'Fantasy', '2021-11-19', 'Finn Wolfhard, Mckenna Grace', '02:04:00'),
('Downton Abbey: A New Era', 'Drama', '2022-03-17', 'Hugh Bonneville, Michelle Dockery', '02:23:00');
*/
INSERT INTO Film (title, film_type, release_date, actors, duration, image1, image2) VALUES
('Spider-Man: No Way Home', 'Action', '2021-12-15', 'Tom Holland, Zendaya', '02:28:00', 'https://image.over-blog.com/CTzM3GtwJopHQX6FoZU5lI7Gsoo=/filters:no_upscale()/image%2F0995735%2F20211203%2Fob_afa363_untitled-1-41.jpg', 'https://media-assets.vanityfair.it/photos/61a0c30a71c4862227952457/16:9/w_2560%2Cc_limit/reo.jpeg'),
('Dune', 'Science-Fiction', '2021-09-15', 'Timothée Chalamet, Zendaya', '02:35:00', 'https://mr.comingsoon.it/imgdb/locandine/big/55957.jpg', 'https://phototrend.fr/wp-content/uploads/2022/03/dune-affiche.jpg'),
('Eternals', 'Action', '2021-10-18', 'Angelina Jolie, Richard Madden', '02:37:00', 'https://images.moviesanywhere.com/acdd3c73c67d756fb920845ad7c88c8f/eb62e721-3ce3-4ec0-b44c-1bd8bc073d87.jpg', 'https://m.media-amazon.com/images/M/MV5BYzFmZDQ3ZjAtYTQ2Ni00ZWY5LWI0OGQtNjlmZDhiNjRmYmFlXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_.jpg'),
('No Time to Die', 'Action', '2021-09-28', 'Daniel Craig, Léa Seydoux', '02:43:00', 'https://m.media-amazon.com/images/M/MV5BYWQ2NzQ1NjktMzNkNS00MGY1LTgwMmMtYTllYTI5YzNmMmE0XkEyXkFqcGdeQXVyMjM4NTM5NDY@._V1_.jpg', 'https://static1.colliderimages.com/wordpress/wp-content/uploads/2021/09/007-no-time-to-die.jpg'),
('Black Widow', 'Action', '2021-07-07', 'Scarlett Johansson, Florence Pugh', '02:14:00', 'https://fr.web.img2.acsta.net/pictures/21/06/30/13/37/5245550.jpg', 'https://images.thedirect.com/media/article_full/black-widow-characters.jpg'),
('Shang-Chi and the Legend of the Ten Rings', 'Action', '2021-09-01', 'Simu Liu, Awkwafina', '02:12:00', 'https://cdn0-production-images-kly.akamaized.net/UMgBFvYF92XfTQ6WUoyFF72s6qY=/800x1066/smart/filters:quality(75):strip_icc():format(webp)/kly-media-production/medias/3583521/original/059777100_1632628838-Shang-Chi_and_the_Legend_of_the_Ten_Rings_0.jpg', 'https://cdn.vox-cdn.com/thumbor/fQuQiQlpbJcxYqikdExfnDBpbYk=/0x0:1633x1128/1200x480/filters:focal(679x277:939x537)/cdn.vox-cdn.com/uploads/chorus_image/image/69152266/STB_Teaser_1_Sht_v4_lg.0.jpg'),
('The Matrix Resurrections', 'Science-Fiction', '2021-12-22', 'Keanu Reeves, Carrie-Anne Moss', '02:28:00', 'https://media.senscritique.com/media/000020350782/300/matrix_resurrections.png', 'https://imgsrc.cineserie.com/2022/09/the-matrix-resurrections-h2.jpeg?ver=1'),
('Venom: Let There Be Carnage', 'Action', '2021-09-30', 'Tom Hardy, Woody Harrelson', '01:37:00', 'https://fr.web.img2.acsta.net/pictures/21/09/01/11/19/0900123.jpg', 'https://chocobonplan.com/wp-content/uploads/2021/05/venom-2-1.jpg'),
('Ghostbusters: Afterlife', 'Fantasy', '2021-11-19', 'Finn Wolfhard, Mckenna Grace', '02:04:00', 'https://pics.filmaffinity.com/Ghostbusters_Afterlife-667822266-large.jpg', 'https://thestylus.org/wp-content/uploads/2021/11/ghostbusters_afterlife.jpg'),
('Downton Abbey: A New Era', 'Drama', '2022-03-17', 'Hugh Bonneville, Michelle Dockery', '02:23:00', 'https://fr.web.img4.acsta.net/pictures/22/02/15/09/10/5252741.jpg', 'https://i0.wp.com/www.haworthcinema.org.uk/wp-content/uploads/2022/08/downton-web.jpg?fit=900%2C467&ssl=1');

INSERT INTO Users (user_name, password, id_film)
VALUES
('Johann', 'psdJohann', 1),
('Aymen', 'psdAymen', 2),
('Marie-France', 'psdMarieFrance', 3),
('user4', 'password4', 4),
('user5', 'password5', 5),
('user6', 'password6', 6),
('user7', 'password7', 7),
('user8', 'password8', 8),
('user9', 'password9', 9),
('user10', 'password10', 10);

INSERT INTO Cinema (name_cine, street_num, street_name)
VALUES
('Cinéma Paradis', 123, 'Rue de la Paix'),
('Majestic Ciné', 456, 'Avenue des Champs-Élysées'),
('Star Cinéma', 789, 'Boulevard Voltaire'),
('Cinéville', 101, 'Rue du Faubourg Saint-Antoine'),
('Le Cinéphile', 222, 'Avenue de la République'),
('Cinéma Royal', 333, 'Rue Royale'),
('Mégaplex', 444, 'Boulevard Haussmann'),
('Cinémathèque', 555, 'Avenue George V'),
('Cinétoile', 666, 'Rue des Arts'),
('Starcine', 777, 'Avenue Victor Hugo');

INSERT INTO City (id_city, city_name, id_cine)
VALUES
('75001', 'Paris', 1),
('75008', 'Paris', 2),
('75011', 'Paris', 3),
('75012', 'Paris', 4),
('75010', 'Paris', 5),
('69001', 'Lyon', 6),
('69002', 'Lyon', 7),
('13001', 'Marseille', 8),
('13002', 'Marseille', 9),
('33000', 'Bordeaux', 10);

INSERT INTO Projeter (id_film, id_cine)
VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10);
