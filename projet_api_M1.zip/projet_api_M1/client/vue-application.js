/**
 * API fonctionnel:
 * --->Faire des requetes pour:
 *        tirer les films via Ville.vue
 *        selectionner un film pour passer de Homeview à Movie
 *        Ajouter des elements dans la liste
 * --->S'inscrire
 */

const Homeview = window.httpVueLoader('./components/Homeview.vue')
const Homeroot = window.httpVueLoader('./views/Homeroot.vue')
const Movie = window.httpVueLoader('./views/Movie.vue')

const Panier = window.httpVueLoader('./views/Panier.vue')
const Login = window.httpVueLoader('./views/Login.vue')
const Signin = window.httpVueLoader('./views/Signin.vue')
const Ville = window.httpVueLoader('./views/Ville.vue')

const routes = [
  { path: '/', component: Homeview},
  { path: '/homeroot', component: Homeroot},
  { path: '/movie', component: Movie},
  { path: '/film/:id', component: Movie},

  { path: '/panier', component: Panier},
  { path: '/login', component: Login},
  { path: '/signin', component: Signin},
  { path: '/ville', component: Ville},
]
// console.log("efzefez")
const router = new VueRouter({
  routes
})

var app = new Vue({
  router,
  el: '#app',
  data: {
    // "cities" : cities,
    // "films" : films,
    // "users" : users,
    'cities': [
      // {'postal_code': 'Paris 75001', 'city_name': 'Paris', 'city_id': 1},
      {'postal_code': '75001', 'city_name': 'Paris', 'city_id': 1},
      {'postal_code': '75008', 'city_name': 'Paris', 'city_id': 2},
      {'postal_code': '75011', 'city_name': 'Paris', 'city_id': 3},
      {'postal_code': '75012', 'city_name': 'Paris', 'city_id': 4},
      {'postal_code': '75010', 'city_name': 'Paris', 'city_id': 5},
      {'postal_code': '69001', 'city_name': 'Lyon', 'city_id': 6},
      {'postal_code': '69002', 'city_name': 'Lyon', 'city_id': 7},
      {'postal_code': '13001', 'city_name': 'Marseille', 'city_id': 8},
      {'postal_code': '13002', 'city_name': 'Marseille', 'city_id': 9},
      {'postal_code': '33000', 'city_name': 'Bordeaux', 'city_id': 10}
    ],
    films: [
      {
        id: 1,
        title: "Spider-Man: No Way Home",
        film_type: 'Action',
        image1: "https://image.over-blog.com/CTzM3GtwJopHQX6FoZU5lI7Gsoo=/filters:no_upscale()/image%2F0995735%2F20211203%2Fob_afa363_untitled-1-41.jpg",
        image2: "https://media-assets.vanityfair.it/photos/61a0c30a71c4862227952457/16:9/w_2560%2Cc_limit/reo.jpeg",
        release_date: '2021-12-15',
        producer: "Emily Fong",
        sessions: [
          { place: '75001', date: '18 Dec 2023', hour: '12h30', city: [{ 'postal_code': '75001', 'city_name': 'Paris', 'city_id': 1 }] },
          { place: '33000', date: '20 Dec 2023', hour: '14h30', city: [{ 'postal_code': '33000', 'city_name': 'Bordeaux', 'city_id': 10 }] },
          { place: '69002', date: '24 Dec 2023', hour: '16h00', city: [{ 'postal_code': '69002', 'city_name': 'Lyon', 'city_id': 7 }] }
        ],
        actors: 'Tom Holland, Zendaya',
        duration: '02:28:00'
      },
      {
        id: 2,
        title: "Dune",
        film_type: 'Science-Fiction',
        image1: "https://mr.comingsoon.it/imgdb/locandine/big/55957.jpg",
        image2: "https://phototrend.fr/wp-content/uploads/2022/03/dune-affiche.jpg",
        release_date: '2021-09-15',
        producer: "Jon Spaihts",
        sessions: [
          { date: '22 Dec 2023', hour: '11h00', city: [{ 'postal_code': '13001', 'city_name': 'Marseille', 'city_id': 8 }] },
          { date: '23 Dec 2023', hour: '18h45', city: [{ 'postal_code': '75008', 'city_name': 'Paris', 'city_id': 2 }] },
          { date: '24 Dec 2023', hour: '13h15', city: [{ 'postal_code': '69001', 'city_name': 'Lyon', 'city_id': 6 }] }
        ],
        actors: 'Timothée Chalamet, Zendaya',
        duration: '02:35:00'
      },
      {
        id: 3,
        title: "Eternals",
        film_type: 'Action',
        image1: "https://images.moviesanywhere.com/acdd3c73c67d756fb920845ad7c88c8f/eb62e721-3ce3-4ec0-b44c-1bd8bc073d87.jpg",
        image2: "https://m.media-amazon.com/images/M/MV5BYzFmZDQ3ZjAtYTQ2Ni00ZWY5LWI0OGQtNjlmZDhiNjRmYmFlXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_.jpg",
        release_date: '2021-10-18',
        producer: "Chloé Zhao",
        sessions: [
          { place: '13002', date: '26 Dec 2023', hour: '10h30', city: [{ 'postal_code': '13002', 'city_name': 'Marseille', 'city_id': 9 }] },
          { place: '75010', date: '27 Dec 2023', hour: '17h00', city: [{ 'postal_code': '75010', 'city_name': 'Paris', 'city_id': 5 }] },
          { place: '75011', date: '28 Dec 2023', hour: '14h00', city: [{ 'postal_code': '75011', 'city_name': 'Paris', 'city_id': 3 }] }
        ],
        actors: 'Angelina Jolie, Richard Madden',
        duration: '02:37:00'
      },
      {
        id: 4,
        title: "No Time to Die",
        film_type: 'Action',
        image1: "https://m.media-amazon.com/images/M/MV5BYWQ2NzQ1NjktMzNkNS00MGY1LTgwMmMtYTllYTI5YzNmMmE0XkEyXkFqcGdeQXVyMjM4NTM5NDY@._V1_.jpg",
        image2: "https://static1.colliderimages.com/wordpress/wp-content/uploads/2021/09/007-no-time-to-die.jpg",
        release_date: '2021-09-28',
        producer: "Cary Joji Fukunaga",
        sessions: [
          { place: '75011', date: '26 Dec 2023', hour: '16h15', city: [{ 'postal_code': '75011', 'city_name': 'Paris', 'city_id': 3 }] },
          { place: '75001', date: '28 Dec 2023', hour: '18h30', city: [{ 'postal_code': '75001', 'city_name': 'Paris', 'city_id': 1 }] },
          { place: '69002', date: '4 Jan 2024', hour: '12h45', city: [{ 'postal_code': '69002', 'city_name': 'Lyon', 'city_id': 7 }] }
        ],
        actors: 'Daniel Craig, Léa Seydoux',
        duration: '02:43:00'
      },
      {
        id: 5,
        title: "Black Widow",
        film_type: 'Action',
        image1: "https://fr.web.img2.acsta.net/pictures/21/06/30/13/37/5245550.jpg",
        image2: "https://images.thedirect.com/media/article_full/black-widow-characters.jpg",
        release_date: '2021-07-07',
        producer: "David Hayter",
        sessions: [
          { place: '69002', date: '30 Dec 2023', hour: '19h20', city: [{ 'postal_code': '69002', 'city_name': 'Lyon', 'city_id': 7 }] },
          { place: '75001', date: '6 Jan 2024', hour: '13h45', city: [{ 'postal_code': '75001', 'city_name': 'Paris', 'city_id': 1 }] },
          { place: '33000', date: '4 Jan 2024', hour: '15h30', city: [{ 'postal_code': '33000', 'city_name': 'Bordeaux', 'city_id': 10 }] }
        ],
        actors: 'Scarlett Johansson, Florence Pugh',
        duration: '02:14:00'
      },
      {
        id: 6,
        title: 'Shang-Chi and the Legend of the Ten Rings',
        image1: "https://cdn0-production-images-kly.akamaized.net/UMgBFvYF92XfTQ6WUoyFF72s6qY=/800x1066/smart/filters:quality(75):strip_icc():format(webp)/kly-media-production/medias/3583521/original/059777100_1632628838-Shang-Chi_and_the_Legend_of_the_Ten_Rings_0.jpg",
        image2: "https://datg-cms-source-repo.s3.amazonaws.com/ABC/DisneyPlusMisc/H_DisneyDay_16x9_ShangChi/e72f340c-73f9-47e7-8d34-dba9111332bf.jpg",
        film_type: 'Action',
        release_date: '2021-09-01',
        producer: "Sean Miyashiro",
        sessions: [
          { place: '69002', date: '6 Jan 2024', hour: '11h15', city: [{ 'postal_code': '69002', 'city_name': 'Lyon', 'city_id': 7 }] },
          { place: '13001', date: '8 Jan 2024', hour: '16h00', city: [{ 'postal_code': '13001', 'city_name': 'Marseille', 'city_id': 8 }] },
          { place: '75008', date: '10 Jan 2024', hour: '12h00', city: [{ 'postal_code': '75008', 'city_name': 'Paris', 'city_id': 2 }] }
        ],
        actors: 'Simu Liu, Awkwafina',
        duration: '02:12:00'
      },
      {
        id : 7,
        title: 'The Matrix Resurrections',
        image1: "https://media.senscritique.com/media/000020350782/300/matrix_resurrections.png",
        image2: "https://imgsrc.cineserie.com/2022/09/the-matrix-resurrections-h2.jpeg?ver=1",
        film_type: 'Science-Fiction',
        release_date: '2021-12-22',
        actors: ('Keanu Reeves', 'Carrie-Anne Moss'),
        producer: "Lana Wachowski",
        sessions:
        [
          { place: 'Lyon 69001', date: '30 Jan 2024', hour: '12h15', city: [{ 'postal_code': '69001', 'city_name': 'Lyon', 'city_id': 6 }]  },
          { place: 'Marseilles 13002', date: '1 Feb 2024', hour: '15h45', city:[{'postal_code': '13002', 'city_name': 'Marseille', 'city_id': 9}]},
          { place: 'Paris 75010', date: '3 Feb 2024', hour: '10h30', city:[{'postal_code': '75010', 'city_name': 'Paris', 'city_id': 5}] }
        ],
        duration: '02:28:00'
      },
      {
        id : 8,
        title: 'Venom: Let There Be Carnage',
        image1: "https://fr.web.img2.acsta.net/pictures/21/09/01/11/19/0900123.jpg",
        image2: "https://chocobonplan.com/wp-content/uploads/2021/05/venom-2-1.jpg",
        film_type: 'Action',
        release_date: '2021-09-30',
        actors: 'Tom Hardy, Woody Harrelson',
        producer: "Matt Tolmach",
        sessions:
        [
          { date: '12 Jan 2024', hour: '19h45', city: [{ 'postal_code': '69002', 'city_name': 'Lyon', 'city_id': 6 }]},
          { date: '14 Jan 2024', hour: '10h00', city:[{'postal_code': '13002', 'city_name': 'Marseille', 'city_id': 9}] },
          { date: '16 Jan 2024', hour: '15h15', city:[{'postal_code': '75010', 'city_name': 'Paris', 'city_id': 5}] }
        ],
        duration: '01:37:00'
      },
      {
        id : 9,
        title: 'Ghostbusters: Afterlife',
        image1: "https://images.fandango.com/ImageRenderer/0/0/redesign/static/img/default_poster.png/0/images/masterrepository/Fandango/219412/GBAL_OnLine_667x1000.jpg",
        image2: "https://thestylus.org/wp-content/uploads/2021/11/ghostbusters_afterlife.jpg",
        film_type: 'Action', 
        release_date: '02:04:00',
        actors: 'Finn Wolfhard, Mckenna Grace',
        producer: "Jason Reitman",
        sessions:
        [
          { place: 'Paris 75011', date: '18 Jan 2024', hour: '14h30', city:[{'postal_code': '75011', 'city_name': 'Paris', 'city_id': 3}] },
          { place: 'Lyon 69002', date: '20 Jan 2024', hour: '16h45', city: [{ 'postal_code': '69002', 'city_name': 'Lyon', 'city_id': 6 }] },
          { place: 'Paris 75001', date: '22 Jan 2024', hour: '11h30', city:[{'postal_code': '75001', 'city_name': 'Paris', 'city_id': 1}] }
        ],
        city:[{'postal_code': 'Lyon 69001', 'city_name': 'Lyon', 'city_id': 6}],
        duration: '2021-11-19'
      },
      {
        id : 10,
        title: 'Downton Abbey: A New Era',
        image1: "https://fr.web.img4.acsta.net/pictures/22/02/15/09/10/5252741.jpg",
        image2: "https://i0.wp.com/www.haworthcinema.org.uk/wp-content/uploads/2022/08/downton-web.jpg?fit=900%2C467&ssl=1",
        film_type: 'Drama',
        release_date: '2022-03-17',
        actors: 'Hugh Bonneville, Michelle Dockery',
        producer: "Julian Fellowes",
        sessions:
        [
          { place: 'Bordeaux 33000', date: '24 Jan 2024', hour: '18h00', city:[{'postal_code': '33000', 'city_name': 'Bordeaux', 'city_id': 10}]},
          { place: 'Lyon 69002', date: '26 Jan 2024', hour: '13h00', city: [{ 'postal_code': '69002', 'city_name': 'Lyon', 'city_id': 6 }] },
          { place: 'Paris 75008', date: '28 Jan 2024', hour: '17h30', city: [{'postal_code': '75008', 'city_name': 'Paris', 'city_id': 2}] }
        ],
        duration: '02:23:00'
}
    ],
    users:[
    {
      id: 1,
      username: "root",
      password:"root"
    },
    {
      id: 2,
      username: "user1",
      password:"user1"
    },
    {
      id: 3,
      username: "user2",
      password:"user2"
    },

    ],
    // articles: [],
    isConnect : -1,
    panier: {
      createdAt: null,
      updatedAt: null,
      articles: []
    }
  },

  async mounted () {
    //Recuperation de la liste de tous les pc
    const res = await axios.get('/api/articles')
    this.articles = res.data
    var homeroot = document.getElementById("homeroot")
    homeroot.style.visibility = "hidden"
  },

  methods: {
    // updateDataVue(otherfilms){
    //   this.films = otherfilms
    //   // this.users = otherusers
    //   // this.cities = othercities
    // },
    // updateDataApi(otherfilms, otherusers, othercities){
    //   otherfilms = this.films
    //   otherusers = this.users
    //   othercities = this.cities
    //   return[otherfilms, otherusers, othercities]
    // },
    async addpanier (articleId) {
      if(this.isConnect == -1){
        alert("Connectez-vous ou inscrivez-vous avant d'ajouter un article dans le panier")
        router.replace('/login')
      }
      else{
        const res = await axios.post('http://localhost:3000/api/panier/', articleId)
        console.log("articleId")
        if(res.data == 1){
          alert("Article ajouté au panier")
        } 
      }
    },

    async updateArticle (newArticle) {
      await axios.put('/api/article/' + newArticle.id, newArticle)
      const article = this.artcle.image
      article.price = newArticle.priceicles.find(a => a.id === newArticle.id)
      article.name = newArticle.name
      article.description = newArticle.description
      article.image = newArti
    },

    async deletearticle (articleId) {
      await axios.delete('/api/article/'+ articleId).then(async res =>{
        if(res == -1) alert('erreur de suppression')
        else{
          alert('article supprimé')
          document.location.reload()
        }
        
      }).catch(err => {
        console.log(err)
      })

    },

    async addUser (user) {
      const res = await axios.post('/api/user/signin', user)
    },

    async addarticle (film) {
      console.log("obj to add: ", film)
      const res = await axios.post('/api/films/adding', film)
      // this.films = res.data
      this.films.push(res.data)
      console.log("Dans vue: ", res.data)
      console.log("Comparé à : ", this.films[1])
      //On reccharge la page après un ajout pour pouvoir voir les articles
      // document.location.reload()
    },

    async checkuser (infoUser) {
      const res  = await axios.post('api/user/login', infoUser)
      // console.log("res : " + res.data)
      /**
       * Les valeurs possibles que peut retournées la requête "/api/user/login" sont:
       * => 1 si l'utilisateur existe et est l'administrateur (email: root@root | mot de passe : mdproot)
       * => 0 si l'utilisateur existe et n'est pas l'administrateur (utilisateur quelconque)
       * => -1 si l'utilisateur n'existe pas
       */
      if(res.data == -1) alert("Utilisateur inexistant.Vous pouvez vous inscrire")
      else if(res.data == 1){
          alert("Utilisateur existant : root connecté")
          // this.isConnect = 1
          // var home = document.getElementById("home")
          // var homeroot = document.getElementById("homeroot")
          // var panier = document.getElementById("panier")
          // var login = document.getElementById("login")
          // login.textContent = 'Log out'
          // login.style.backgroundColor = "blue"
          // login.style.color = "white"
          /**
           * L'admin n'est pas censé voir les pages suivantes:
           * => home
           * => panier
           * On rend visile la root "homeroot"
           */
          // home.style.visibility = "hidden"
          // panier.style.visibility = "hidden"
          // homeroot.style.visibility = "visible"
          router.replace('/homeroot')
        }

        else if(res.data == 0){
          
          alert("Bienvenu")
          this.isConnect = 1
          var home = document.getElementById("home")
          var homeroot = document.getElementById("homeroot")
          var panier = document.getElementById("panier")
          /**
           * L'utilisateur n'est pas censé voir la page suivante:
           * => homeroot
           * On rend visile la root "homeroot"
           */
          home.style.visibility = "visible"
          panier.style.visibility = "visible"
          homeroot.style.visibility = "hidden"
          var login = document.getElementById("login")
          login.textContent = 'Log out'
          login.style.backgroundColor = "green"
          login.style.color = "white"
          router.replace('/')
        }
      },

      async logout (){
        if(this.isConnect == -1){
          alert("Aucun utilisateur connecté")
        }
        else{
          var home = document.getElementById("home")
          var homeroot = document.getElementById("homeroot")
          var panier = document.getElementById("panier")
          var login = document.getElementById("login")
          alert("Merci et à bientôt !")
          home.style.visibility = "visible"
          panier.style.visibility = "visible"
          homeroot.style.visibility = "hidden"
          login.textContent = 'Log in'
          login.style.backgroundColor = "white"
          login.style.color = "#ff6600"
          router.replace("/")
          this.isConnect == -1
        }
      }
  }
  
})

// module.exports = app;