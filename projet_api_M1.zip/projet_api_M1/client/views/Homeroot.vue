<template>
    <div id="homeroot">
  
    <div class="frameP">
      <div class="frame">
        
        <!-- <h2 class="rubrique">PC PORTABLES GAMER - ORDINATEURS PORTABLES GAMING</h2> -->
        <div class="cards">
            <div class="card" v-for="film in films" :key="film.id">
                <router-link :to="'/film/' + film.id">
                    <img id="im1" v-bind:src="film.image1" alt="Film Poster">
                    <div class="text">
                        <div class="header">
                            <h5 class="name">{{film.title}}</h5>
                            <h5 class="type">{{film.type}}</h5>
                        </div>
                    </div>
                </router-link>
            </div>
        </div>
        <!-- <div class="cards" >
            
                <div id = "card2" class="card" v-for="article in articles">
                    <div class="images">
                        <img id="im1" v-bind:src="article.image" alt="PC PORTABLE GAMER">
                    </div>
                    <div class="text">
                        <div class="card-header">
                            <h4 class="id">ID : {{article.id_article}}</h4>
                            <h4 class="serie">Pc Portable {{article.name}} {{article.serie}}</h4>
                            <h4 class="prix">{{article.price}} {{article.devise}}</h4>
                            <div class="description">
                                <ul>
                                    <li>
                                        Ecran {{article.ecran}}
                                    </li>
                                    <li>
                                        Processeur {{article.processeur}}
                                    </li>
                                    <li>
                                        RAM {{article.ram}} {{article.typeRam}} - {{article.rom}} {{article.typeRom}}
                                    </li>
                                    <li>
                                        {{article.graphicCardName}}
                                        {{article.graphicCardSerie}}
                                        {{article.graphicCardCapacity}}
                                    </li>
                                    <li>
                                        {{article.os}}
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="btns">

                            <div class="btn">
                                <h5 class="dispo" v-if="article.state == 'dispo'">En stock</h5>
                                <h5 class="indispo" v-else>Indisponible</h5>
                                <button @click.prevent="deletearticle(article.id_article)" id="add">Retirer du catalogue</button>
                            </div>
                        </div>
                    </div>
            </div>
        </div> -->
            
        <!-- <largecardroot @deletearticle='deletearticle' :article="article"></largecardroot> -->
        <!-- <h2>{{marque.articles.name}}</h2> -->
        <!-- <largecard :article = "marque.articles"></largecard> -->
        
      </div>
      <div class="formulaire">
        <h4 class="title">AJOUTER UN FILM</h4>
        <form>
            <div class="champ">
                <div class="info title">
                    <h6 class="title">Titre</h6>
                    <input v-model="film.title" type="text" class="name">
                </div>
                <div class="info film_type">
                    <h6 class="title">Type</h6>
                    <input v-model="film.film_type" type="text" class="name">
                </div>
                <div class="info image1">
                    <h6 class="title">Image carte</h6>
                    <input v-model="film.image1" type="text" class="image">
                </div>
                <div class="info image2">
                    <h6 class="title">Image couverture</h6>
                    <input v-model="film.image2" type="text" class="image">
                </div>
                <div class="info duration">
                    <h6 class="title">Durée</h6>
                    <input v-model="film.duration" type="text" class="serie">
                </div>
                <div class="info realease_date">
                    <h6 class="title">Date de sortie</h6>
                    <input v-model="film.realease_date" type="text" class="ecran">
                </div>
                <div class="info actors">
                    <h6 class="title">Acteurs</h6>
                    <input v-model="film.actors" type="text" class="processeur">
                </div>
                <div class="info producer">
                    <h6 class="title">Producteur</h6>
                    <input v-model="film.producer" type="text" class="processeur">
                </div>
                <div class="infos sessions">
                    <div class="head">
                        <h6 class="title">Sessions</h6>
                        <button @click.prevent="incrementCpt">+</button>
                    </div>
                    <div v-for="index in cpt" :key="index" class="body">
                        <div class="date">
                            <h6 class="title">Date</h6>
                            <input v-model="sessions[index-1].date" type="text" class="date">
                        </div>
                        <div class="heure">
                            <h6 class="title">Heure</h6>
                            <input v-model="sessions[index-1].hour" type="text" class="heure">
                        </div>
                        <div class="cities">
                            <h6 class="title">Ville</h6>
                            <select class="select" v-model="sessions[index-1].city" name="">
                            <option :value="{city}" v-for="city in cities" :key="city.id">
                                {{ city.postal_code }}, {{ city.city_name }}
                            </option>
                            <option value="all">Toutes les villes</option>
                            </select>
                        </div>
                    </div>

                </div>
                <!-- <h2 class="graphicard">Mémoire Ram</h2>
                <div class="ram-general join">
                    <div class="info Ram">
                        <h6 class="title">Capacité Ram</h6>
                        <input v-model="film.Ram" type="text" class="Ram">
                    </div>
                    <div class="info typeRam">
                        <h6 class="title">Type Ram</h6>
                        <input v-model="film.typeRam" type="text" class="typeRam">
                    </div>
                </div>
                <h2 class="graphicard">Mémoire Rom</h2>
                <div class="rom-general join">
                    <div class="info rom">
                        <h6 class="title">Capacité Rom</h6>
                        <input v-model="film.rom" type="text" class="rom">
                    </div>
                    <div class="info typeRom">
                        <h6 class="title">Type Rom</h6>
                        <input v-model="film.typeRom" type="text" class="typeRom">
                    </div>
                </div>
                <div class="info os">
                    <h6 class="title">Système d'exploitation</h6>
                    <input v-model="film.os" type="text" class="os">
                </div>
                <div class="info code">
                    <h6 class="title">Code</h6>
                    <input v-model="film.code" type="text" class="code">
                </div>
                <h2 class="graphicard">Carte graphique</h2>
                <div class="info graphicCard-general">
                    <div class="info graphName">
                        <h6 class="title">Marque</h6>
                        <select v-model="film.name" name="marque" id="marque">
                            <option value="Asus">Asus</option>
                            <option value="Dell">Dell</option>
                            <option value="Hp">Hp</option>
                            <option value="MSI">MSI</option>
                        </select>
                    </div>
                    <div class="info graphSerie">
                        <h6 class="title">Série</h6>
                        <input v-model="film.graphicCardSerie" type="text" class="graphSerie">
                    </div>
                    <div class="info graphCapacity"> 
                        <h6 class="title">Capacité</h6>
                        <input v-model="film.graphicCardCapacity" type="text" class="graphCapacity">
                    </div>
                </div>
                <div class="info price">
                    <h6 class="title">Prix</h6>
                    <input v-model="film.price" type="text" class="price">
                </div>-->
            </div>  
            <div class="btn">

                <button @click.prevent="addarticle">Ajouter</button>
            </div>
        </form>
      </div>
    </div>
  </div>
  </template>

  <script type= "module">   
  
  module.exports =  {
    name:'homeroot',
    props:{
        films: [],
        cities: []
    },
    data(){
        return{
            cpt : 1,
            selectedCity : {},
            session:{},
            sessions:[],
            film:   {
                id: this.films.length+1,
                title: "",
                film_type: '',
                image1: "",
                image2: "",
                release_date: '',
                producer: "",
                sessions: [
                ],
                actors: '',
                duration: ''

            },
        }
    },
    created(){
        this.sessions.push(this.session)
        console.log("creation : ", this.sessions)
    },
    methods:{
        deletearticle(articleId){
            this.$emit("deletearticle", articleId)
        },
        addarticle(){
            console.log("Valeur de sessions", this.sessions)
            this.sessions = this.sessions.map((session) => {
                session.city = session.city.city
                return session
            }) 
            console.log("Valeur de sessions aprs : ", this.sessions)
            this.film.sessions = this.sessions

            // this.film.sessions = this.sessions
            this.$emit("addarticle", this.film)
        },
        incrementCpt(){
            this.cpt += 1
            // this.sessions.push({})
            this.sessions.push({ date: '', hour: '', city: {} });
            console.log("sessions : ", this.sessions)

        }
    }
  }
  </script>
  
  <style scoped>
  @import url('https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@600&display=swap');   
  .sessions{
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    margin-bottom: 4%;
  }
  .sessions .head button{
    width: 15%;
    height: 30px;
  }
  .sessions .head{
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    width: 100%;
  }
  .sessions .body{
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    margin-bottom: 2%;
  }
  .sessions input{
    width: 80%;

  }

  .frameP{
        margin-top: 3%;
        margin-bottom: 3%;
        display: flex;
        flex-direction: row;
        align-items: flex-start;
        justify-content: space-around;
        width: 100%;
    }
    div.formulaire{
        position: sticky;
        top: 100px;
        width: 30%;
        height: 600px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
        background-color: red;
        box-shadow: 0px 30px 30px -20px rgba(0, 0, 0, 0.315);
        overflow-y: scroll;
    }
    div.formulaire h4{
        width: 70%;
        margin-top: 30%;
        margin-bottom: 20px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        color: #002060;
        font-size: 25px;
        border-bottom: 2px solid #002060;
    }
    div.formulaire form{
        width: 85%;
    }
    div.formulaire form div.champ{
        width: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: flex-start;
    }
    div.formulaire form div.champ .info{
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        justify-content: center;
        margin-bottom: 15px;
    }
    div.formulaire form div.champ .info h6, h6.title{
        font-size: 17px;
        /* color: #002060; */
        color: white;
    }

    div.formulaire form div.champ .info select{
        width: 40%;
        border-radius: 3px;
        cursor: pointer;
        border: none;
        color:white;
        font-size: 15px;
        height: 25px;
        padding-left: 10px;
    }
    div.formulaire form div.champ .info input{
        outline: none;
        border: none;
        margin-top: 2px;
        background-color: rgba(232, 232, 232, 0.642);
        color: white;
        padding: 0px 10px;
        width: 100%;
        height: 30px;
        border-radius: 3px;
        font-size: 15px;
  }
    div.formulaire form div.champ .join{
        width: 100%;
        display: flex;
        flex-direction: row;
        align-items: flex-start;
        justify-content: center;
    }
    div.formulaire form div.champ .join input{
        width: 60%;
    }
    div.formulaire form div.champ h2{
        color: rgb(0, 140, 255);
    }
    div.formulaire form .btn{
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 20px;
    }
    div.formulaire form button{
    width: 50%;
    height: 50px;
    color: red;
    background-color: white;
    border: none;
    border-radius: 7px;
    transition: 0.2s;
    }
    div.formulaire form button:hover{
        cursor: pointer;
        color: red;
        background-color: rgb(237, 229, 229);
        border: none;
        border-radius: 7px;
        transition: 0.3s;
    }
    .frameP h2{
    margin-left: 5%;
    font-size: 25px;
    font-family: 'Source Sans Pro', sans-serif;
    color: #545454; 
    }
  
    .link-cat{
        color: #00B0F0;
        margin: 8px;
        font-size: 15px;
        text-decoration: none;
        margin-right: 20px;
        transition: 0.2s;
    }
    div.frameP div.frame{
        display: flex;
        flex-direction: column;
        width: 55%;
        flex-wrap: wrap;
        align-items: center;
        justify-content: center;
    }
    div.frameP div.frame h2{
        display: flex;
        flex-direction: column;
        width: 90%;
        flex-wrap: wrap;
        align-items: flex-start;
        justify-content: flex-start;
    }
    div.cards{
      /* background-color: #FF0000; */
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: flex-start;
      flex-wrap: wrap;
      width: 100%;
      height: 100%;
      /* margin-top: 3%; */
      /* margin: 3% 0 3% 0; */
    }
    div.card{
        /* background-color: #04fd5b; */
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        align-items: center;
        width: 25%;
        height: 40%;
        margin-top: 3%;
    }
    div.card img{
        /* width: 200px; */
        width: 100%;
        height: 300px;
    }

    div.card div.text{
        width: 100%;
        height: 100%;
        /* background-color: antiquewhite; */
        margin-top: 2%;
        display : flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        /* padding: 0 2% 0 2%; */
    }

    div.card div.text div.header{
        width: 80%;
        display : flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        padding: 0 1% 0 1%;
    }

    div.card div.text div.header h5{
        width: 70%;
        font-size: 12px;
    }

    div.card div.text div.header h5.type{
        font-size: 15px;
        background-color: #FF0000;
        color: white;
        padding: 5px 15px 5px 15px;
    }

    div.card div.text h5.text{
        display : flex;
        flex-direction: row;
        justify-content: center ;
        align-items: center;
        margin-top: -6%;
        color: #b4b3b3;
        background-color: aliceblue;
        padding: 0px 35px 35px 0px;
    }

  </style>
  