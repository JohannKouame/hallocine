/* __placeholder__ */
module.exports = {
name: 'homeroot',
props: {
films: [],
cities: []
},
data() {
return {
cpt: 1,
selectedCity: {},
session: {},
sessions: [],
film: {
id: this.films.length,
title: "",
film_type: '',
image1: "",
image2: "",
release_date: '',
producer: "",
sessions: [],
actors: '',
duration: ''
},
};
},
created() {
this.sessions.push(this.session);
console.log("creation : ", this.sessions);
},
methods: {
deletearticle(articleId) {
this.$emit("deletearticle", articleId);
},
addarticle() {
console.log("eghehszrhetgherghr", this.sessions);
this.film.sessions = this.sessions;
this.$emit("addarticle", this.film);
},
incrementCpt() {
this.cpt += 1;
this.sessions.push({});
// console.log("sessions : ", this.sessions)
}
}
};
