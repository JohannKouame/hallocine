<template>    
    <div class="frame">
        <div class="head" id="top">
            <div class="overlay"></div>
            <div class="image" :style="{ backgroundImage: 'url(' + film.image2 + ')' }"></div>
            <!-- <img id="im1" class="image" :src="film.image2" alt="Film Poster"> -->
            <!-- <img src="https://media.sudouest.fr/16802965/1200x600/the-creator-film-photo-20th-century-studios-2.jpg" alt="" class="couverture"> -->
            <div class="text">
                <h1 class="title">{{ film.title }}</h1>
                <h2 class="producteur">{{ film.producer }}</h2>
            </div>
        </div>
        <div class="content">
            <div class="left">
                <img id="im1" :src="film.image1" alt="Film Poster">
                <!-- <img src="https://m.media-amazon.com/images/M/MV5BNDUyNTIzNDQtYTZmMi00M2FlLTgyZjUtYWViZWNhMDYzMjE4XkEyXkFqcGdeQXVyMTUzMTg2ODkz._V1_.jpg" alt=""> -->
                <div class="text">
                    <div class="info type">
                        <h2 class="label">Type</h2>
                        <h2 class="value">{{ film.film_type }}</h2>
                    </div>
                    <div class="info actors">
                        <h2 class="label">Acteurs</h2>
                        <h2 class="value">{{ film.actors }}</h2>
                    </div>
                    <div class="info time">
                        <h2 class="label">Durée</h2>
                        <h2 class="value">{{ film.duration }}</h2>
                    </div>
                </div>
            </div>
            <div class="right">
                <div class="head">
                    <!-- <div class="dropbox">
                        <select>
                            <option value="" disabled selected>Sélectionnez une option</option>
                            <option value="option1">Cachan</option>
                            <option value="option2">Montparnasse</option>
                            <option value="option3">Paris</option>
                            <option value="option4">Lille</option>
                        </select>
                    </div> -->
                    <div class="sessions">
                        <div v-for="session in film.sessions" :key="session.id" class="session">
                            <h2 class="place">{{ session.city[0].postal_code }}, {{ session.city[0].city_name }}</h2>
                            <div class="infos">
                                <div class="info">
                                    <div class="date">
                                        <h3 class="day">{{ session.date }}</h3>
                                        <h3 class="hour">{{session.hour}}</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
  
<script type= "module"> 
//Importation des composants
module.exports =  {
    name: 'movie',
    props: {
        film: {},
        films: [],
        panier: { type: Object },
    },
    mounted() {
        this.$nextTick(() => {
            window.scrollTo(0, 0);
        });
    },
    data(){
        return{

        }
    },
    created(){
        const filmId = this.$route.params.id;
        this.film = this.films[filmId-1]
        console.log(this.film.actors)
        window.onload = function() {};

    },
    
    methods:{
    }
}
</script>

<style scoped>

    @import url('https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@600&display=swap');
    .frame .head .image{  
    z-index: -1;  
    position: absolute;
    width: 100%;
    height: 350px;
    background-size: cover;
    background-position: center;
    /* background-size: contain;
    background-repeat: no-repeat;
    background-position: center; */
    }

    .frame .head .text{  
        color: white;
        z-index: 1;  
        position: absolute;
        top: 45%;
        left: 26%;
    }

    .frame .head .text .producteur{
        margin-top: -2%;
    }

    .frame .head .overlay{
        z-index: 0;
        position: absolute;
        width: 100%;
        height: 350px;
        background-color: rgba(0, 0, 0, 0.5); /* Couleur noire avec une opacité de 0.5 */
    }

    .frame .content{
        background-color: bl;
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        z-index: 2;
        width: 100%;
        /* height: 100%; */
    }

    .frame .content .left{
        position: sticky;
        /* background-color: aqua; */
        top: 0%;
        padding: 2% 0 2% 3%;
        z-index: 0;
        width: 20%;
        /* height: 100%; */
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        justify-content: center;
    }

    .frame .content .left img{
        z-index: -1;
        width: 100%;
        height: 30%;
    }

    .frame .content .left .text{
        /* background-color: blue; */
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        justify-content: center;
    }

    .frame .content .left .text .actors .value{
        /* background-color: blue; */
        width: 70%; 
        text-align: right;
        justify-content: flex-end;
        align-items: flex-end;
    }

    .frame .content .left .text .info{
        border-left: 2px solid red;
        /* background-color: aqua; */
        font-size: 10px;
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: space-between;
        margin-top: 2%;
        width: 100%;
        height: 30px;
    }

    .frame .content .left .text .info .label{
        padding-left: 1%;
    }

    .frame .content .right{
        margin-top: 21%;
        z-index: 0;
        width: 75%;
        /* height: 500px; */
    }

    .frame .content .right .head{
        display: flex;
        align-items: center;
        justify-content: space-between;
        position: sticky;
        top: 5%;
        width: 100%;
        height: 150px;
        /* background-color: aqua; */

    }
    .frame .content .right .sessions{
        margin-top: 55%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        width: 100%;
    }
    .sessions .session{
        margin-bottom: 3.5%;
        /* background-color: black; */
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        justify-content: center;
        /* padding-top: 3%;
        padding-bottom: 1%; */
        font-size: 17px;
    }
    .sessions .session .place{
        font-size: 35px;
        /* padding-bottom: 0.7%; */
        margin-bottom: 1.5%;
        border-bottom: 2px solid red;
        width: 50%;
    }
    .sessions .session .infos{
        /* background-color: blanchedalmond; */
        width: 100%;;
        display: flex;
        align-items: flex-start;
        justify-content: flex-start;
        /* padding-top: 3%;
        padding-bottom: 1%; */
        /* font-size: 17px; */
    }
    .sessions .session .infos .info{
        /* background-color: rgb(234, 150, 25); */
        width: 15%;
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        /* padding-top: 3%;
        padding-bottom: 1%; */
        /* font-size: 17px; */
    }

    .date{
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        background-color: red;
        color: white;
        width: 80%;
        height: 100px;
        /* padding-top: 20px; */
        font-weight: 600;
        border-radius: 5px;
        cursor: pointer;
    }
    .sessions .session .infos .info .date .day{
        color: white;
        font-size: 25px;
    }
    .sessions .session .infos .info .date .hour{
        margin-top: 1%;
        color: black;
        font-size: 17px;
    }

</style>
