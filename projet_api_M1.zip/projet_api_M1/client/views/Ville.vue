<template>
    <div class="ville" id="ville">
        <select class="select" v-model="selectedCity.city" @change="filteredFilms" name="">
            <!-- <option :value="{citie}" v-for="citie in this.cities" :key="citie.id" @click="filmByCity(ville)">{{ville}}</option> -->
            <option :value="{city}" v-for="city in this.cities" :key="city.id">
                {{ city.postal_code }}, {{ city.city_name }}
            </option>
            <option value="all">Toutes les villes</option>
        </select>
    
        <div class="cards">
            <div class="card" v-for="film in filteredFilmsList" :key="film.id">
                <router-link :to="'/film/' + film.id">
                    <img id="im1" v-bind:src="film.image1" alt="Film Poster">
                    <div class="text">
                        <div class="header">
                            <h5 class="name">{{film.title}}</h5>
                            <h5 class="type">{{film.type}}</h5>
                        </div>
                    </div>
                </router-link>
            </div>
        </div>
    </div>
</template>
  
  <script type="module">
//   import detail from "../../detail"
  
  module.exports = {
    name: 'ville',
    props: {
        cities: [],
        films:[]
    //   msg: String,
    },
    data() {
      return{
        selectedCity : {},
        drop : false,
        cinema: "",
        citie:[],
        filteredFilmsList:[],
        // cities: [],
        nbr : 0,
        // filmdetail : detail.detailfilm,
        mois: ["JAN","FEV","MAR","AVR","MAI","JUN","JUI","AOUT","SEP","OCT","NOV","DEC"],
        date : []
      }
    },
    methods:{
        filteredFilms() {
            this.filteredFilmsList = this.films
            // if (this.selectedCity && this.selectedCity.city && this.selectedCity.city.postal_code) {
                const selectedPostalCode = this.selectedCity.city.city.city_id;
                // Filtrer les films en fonction du code postal sélectionné
                this.filteredFilmsList = this.films.filter(film => {
                    console.log("code_postal : ", selectedPostalCode)
                    console.log("avant : ", this.films[0].sessions)
                    return film.sessions.some(session => {
                        console.log(session.city.city_id)
                        return session.city.city_id === selectedPostalCode;
                    });
                });
            // }
        },
        // filteredFilms(){
        //     this.filteredFilmsList = this.films
        //     console.log(this.selectedCity.city.city.postal_code)
        //     console.log("avant : ",this.filteredFilmsList[0].city[0].postal_code)
        //     this.filteredFilmsList = this.films.filter(film => film.city[0].postal_code === this.selectedCity.city.city.postal_code);
        //     console.log("après : ",this.filteredFilmsList)
        // }
    },
    
    computed: {
    },
    created(){
        this.filteredFilmsList = this.films
    },
    mounted(){
        // Initialisation de filteredFilms avec les films correspondants à la ville sélectionnée par défaut
        this.filteredFilms();
  }
}

  </script>
  <style>
  .ville{
    display: flex;
    flex-direction: columns;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    /* background-color: #b4b3b3; */
    width: 100%;
    padding-top: 3%;
    /* height: 1000px; */
    /* padding: 0 2% 0 2%; */
  }
  select {
          background: none;
          backdrop-filter: blur(5px);
          color: red;
          display: flex;
          justify-content: space-between;
          align-items: center;
          border: 0.2px red solid;
          border-radius: 0.5em;
          padding: 1em;
          cursor: pointer;
          /* transition: background 0.3s; */
          width: 70%;
          height: 65px;
          margin: auto;
          font-size: 16px;
          font-weight: 500;
          font-family: inherit;
          position: relative;
          top: 60%;
          font-family: Heebo,arial,sans-serif;
          font-size: 20px;
      }
      
      option{
        color: black;
        border: none;
        font-family: Heebo,arial,sans-serif;
        font-size: 15px;
        font-weight: 700;
        height: 2000px;
        width: 100px;
        margin-bottom: 100px;
      }  
      div.cards{
      /* background-color: #FF0000; */
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: flex-start;
      flex-wrap: wrap;
      width: 100%;
      height: 100%;
      /* margin-top: 3%; */
      margin: 3% 0 3% 0;
  }
  div.card{
      /* background-color: #04fd5b; */
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      align-items: center;
      width: 30%;
      height: 40%;
      margin-top: 3%;
  }
  div.card img{
      width: 350px;
      height: 500px;
  }

  div.card div.text{
      width: 100%;
      height: 100%;
      /* background-color: antiquewhite; */
      margin-top: 2%;
      display : flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      /* padding: 0 2% 0 2%; */
  }

  div.card div.text div.header{
      width: 80%;
      display : flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
      padding: 0 1% 0 1%;
  }

  div.card div.text div.header h5{
      font-size: 18px;
  }

  div.card div.text div.header h5.type{
      font-size: 15px;
      background-color: #FF0000;
      color: white;
      padding: 5px 15px 5px 15px;
  }

  div.card div.text h5.text{
      display : flex;
      flex-direction: row;
      justify-content: center ;
      align-items: center;
      margin-top: -6%;
      color: #b4b3b3;
      background-color: aliceblue;
      padding: 0px 35px 35px 0px;
  }
  </style>
  