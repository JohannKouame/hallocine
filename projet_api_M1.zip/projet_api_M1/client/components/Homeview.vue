<template>
  <div id="homecard" class="homecard">
    <div class="head">
      <div class="content">
          <h1 class="title1">REGARDEZ</h1>
          <!-- <img src="The_creator_logo_R.png" alt="" class="logo-film"> -->
          <h1 class="title2">DISPONIBLE MAINTENANT</h1>
          <button class="btn">VOIR LES CINEMAS</button>
          <!-- <img src="./img/cinemas.png" alt="" class="cinemas"> -->
      </div>
    </div>
    <div class="cards">
      <div class="card" v-for="film in films" :key="film.id">
        <router-link :to="'/film/' + film.id">
          <img id="im1" v-bind:src="film.image1" alt="Film Poster">
            <div class="text">
                <div class="header">
                    <h5 class="name">{{film.title}}</h5>
                    <h5 class="type">{{film.type}}</h5>
                </div>
            </div>
        </router-link>
      </div>
    </div>
  </div>
</template>

<script type= "module"> 
  //Importation des composants

  module.exports =  {
    name: 'homecard',
    props: {
      films: [] ,
      panier: { type: Object },
    },
    data(){
      return{
      films: [] ,
      panier: { type: Object },

      }
    },
    
    methods:{
      // getfilms(film){
      //   this.$emit("getfilm", this.film)
      // }
    //   getFilms() {
    //     // Appel à l'API pour obtenir la liste des films lors de la création du composant
    //     axios.get('/api/films')
    //       .then(response => {
    //         this.films = response.data; // Mettre à jour la liste des films avec les données reçues
    //       })
    //       .catch(error => {
    //         console.error('Erreur lors de la récupération des films :', error);
    //   })
    // },
    //   addpanier(articleId){
    //     this.$emit("addpanier", articleId)
    //   },
    // },
  },
  created(){
    
    const path = "http://localhost:3000/films";
            axios.get(path)
            .then ((res) => { 
                this.films = res.data;
                // this.films.forEach(film => {
                //   if(this.villes.indexOf(film.city) == -1){
                //     this.villes.push(film.city)
                //   }
                // this.cinema = "dans tous nos cinémas"
                // this.nbr = this.films.length
                // });
            }) 
            .catch ((error) => {
                console.log(error);
            });
  }
}
</script>

<style scoped>
  @import url('https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@600&display=swap');
  div.head{
    display: flex;
    align-items: flex-start;
    justify-content: flex-start;
    padding-top: 3%;
    width: 100%;
    height: 600px;
    background-color: aqua;
    background-image: url("./img/the_creator.png");
    background-size: cover; /* Ajuste la taille de l'image pour couvrir la div */
    background-position: center;
    /* border-bottom : 2px solid black; 
    border-bottom-width: 10px; */
  }

  div.head div.content{
    margin-top: -2%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 50%;
    /* background-color: aqua; */
    height: 100%;
  }

  div.head div.content .title1{
      margin-top: -5%;
      font-size: 500%;
  }

  div.head div.content .title2{
      margin-top: -17%;
      font-size: 200%;
  }

  div.head div.content img.logo-film{
      margin-top: -12%;
      height: 60%;
      width: 120%;
  }

  div.head div.content button.btn{
    border: none;
    font-size: 100%;
    cursor: pointer;
    padding: 3% 10%;
    background-color: black;
    color: white;
    transition: 0.3s;
  }

  div.head div.content button.btn:hover{
    background-color: #FF0000;
    color: white;
    transition: 0.2s;
  }

  div.frame div.head div.content img.cinemas{
    margin-top: 5%;
    height: 10%;
    width: 50%;
  }
  .homecard{
    display: flex;
    flex-direction: columns;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    /* background-color: #b4b3b3; */
    width: 100%;
    /* height: 100%; */
    /* padding: 0 2% 0 2%; */
  }

  div.cards{
      /* background-color: #FF0000; */
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: flex-start;
      flex-wrap: wrap;
      width: 100%;
      height: 100%;
      /* margin-top: 3%; */
      margin: 3% 0 3% 0;
  }
  div.card{
      /* background-color: #04fd5b; */
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      align-items: center;
      width: 30%;
      height: 40%;
      margin-top: 3%;
  }
  div.card img{
      width: 350px;
      height: 500px;
  }

  div.card div.text{
      width: 100%;
      height: 100%;
      /* background-color: antiquewhite; */
      margin-top: 2%;
      display : flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      /* padding: 0 2% 0 2%; */
  }

  div.card div.text div.header{
      width: 80%;
      display : flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
      padding: 0 1% 0 1%;
  }

  div.card div.text div.header h5{
      font-size: 18px;
  }

  div.card div.text div.header h5.type{
      font-size: 15px;
      background-color: #FF0000;
      color: white;
      padding: 5px 15px 5px 15px;
  }

  div.card div.text h5.text{
      display : flex;
      flex-direction: row;
      justify-content: center ;
      align-items: center;
      margin-top: -6%;
      color: #b4b3b3;
      background-color: aliceblue;
      padding: 0px 35px 35px 0px;
  }
</style>
