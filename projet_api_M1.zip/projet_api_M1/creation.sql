CREATE TABLE Film(
   id_film INT AUTO_INCREMENT,
   title VARCHAR(50) NOT NULL,
   image1 VARCHAR(1000) NOT NULL,
   image2 VARCHAR(1000) NOT NULL,
   film_type VARCHAR(50) NOT NULL,
   release_date DATE NOT NULL,
   actors VARCHAR(200) NOT NULL,
   duration TIME NOT NULL,
   PRIMARY KEY(id_film)
);

CREATE TABLE Users(
   id_user INT AUTO_INCREMENT,
   user_name VARCHAR(50) NOT NULL,
   password VARCHAR(50) NOT NULL, 
   id_film INT NOT NULL,
   PRIMARY KEY(id_user),
   UNIQUE(user_name),
   FOREIGN KEY(id_film) REFERENCES Film(id_film)
);

CREATE TABLE Cinema(
   id_cine INT AUTO_INCREMENT,
   name_cine VARCHAR(50) NOT NULL,
   street_num INT NOT NULL,
   street_name VARCHAR(50) NOT NULL,
   PRIMARY KEY(id_cine)
);

CREATE TABLE City(
   id_city VARCHAR(50),
   city_name VARCHAR(50) NOT NULL,
   id_cine INT NOT NULL,
   PRIMARY KEY(id_city),
   FOREIGN KEY(id_cine) REFERENCES Cinema(id_cine)
);

CREATE TABLE Projeter(
   id_film INT,
   id_cine INT,
   PRIMARY KEY(id_film, id_cine),
   FOREIGN KEY(id_film) REFERENCES Film(id_film),
   FOREIGN KEY(id_cine) REFERENCES Cinema(id_cine)
);

/*DROP TABLE Users;
DROP TABLE Projeter;
DROP TABLE City;
DROP TABLE Film;
DROP TABLE Cinema;
*/
